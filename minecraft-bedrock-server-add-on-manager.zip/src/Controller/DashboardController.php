<?php

namespace App\Controller;

use App\Service\AddonScanner;
use App\Service\DependencyChecker;
use App\Service\ServerMetaReader;
use App\Service\ServerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class DashboardController extends AbstractController
{
    public function __construct(
        private readonly ServerRegistry    $serverRegistry,
        private readonly AddonScanner      $addonScanner,
        private readonly DependencyChecker $dependencyChecker,
        private readonly ServerMetaReader  $serverMetaReader
    ) {}

    #[Route('/admin', name: 'admin_dashboard')]
    public function index(): Response
    {
        $servers = $this->serverRegistry->getAll();

        $serverData = [];
        foreach ($servers as $server) {
            $packs       = $this->addonScanner->scan($server);
            $userPacks   = array_filter($packs, fn($p) => !$p->isSystem);
            $systemPacks = array_filter($packs, fn($p) => $p->isSystem);

            $packsWithDeps = array_map(function ($pack) use ($packs) {
                return [
                    'pack'          => $pack,
                    'unmetDeps'     => $this->dependencyChecker->getUnmetDependencies($pack, $packs),
                    'depsSatisfied' => $this->dependencyChecker->isSatisfied($pack, $packs),
                ];
            }, $userPacks);

            $meta = $this->serverMetaReader->read($server->dataPath);
            $serverData[] = [
                'server'        => $server,
                'meta'          => $meta,
                'packs'         => array_values($packsWithDeps),
                'systemPacks'   => array_values($systemPacks),
                'enabledCount'  => count(array_filter($userPacks, fn($p) => $p->enabled)),
                'disabledCount' => count(array_filter($userPacks, fn($p) => !$p->enabled)),
            ];
        }

        return $this->render('dashboard/index.html.twig', [
            'serverData' => $serverData,
        ]);
    }
}
